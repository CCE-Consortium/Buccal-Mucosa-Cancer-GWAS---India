import os
import pandas as pd
import threading
# convert the summary logistic file to cojo.ma format
# these are the columns that will be needed : SNP A1 A2 freq b se p N
# logistic file outputs from Plink will have : 'CHR', 'SNP', 'BP', 'A1', 'TEST', 'NMISS', 'OR', 'STAT', 'P', 'A1_MinorAllele', 'A2_MajorAllele', 'A1_MinorAlleleFreq', 'MAF_In_Cases', 'MAF_In_Controls', 'NumOf_Allele_Obs_In_Cases', 'NumOf_Allele_Obs_In_Controls' 'A1_HomozygCount', 'HeteroCount', 'A2_HomozygCount', 'A1_HapCount', 'A2_HapCount', 'A1_Count', 'A2_Count', 'BETA', 'SE', 'L95', 'U95'
# Plink meta-analysis output files with BETA, OR etc & allele frequencies added to it will have : 'CHR', 'BP', 'SNP', 'A1', 'A2', 'N', 'P', 'P(R)', 'OR', 'OR(R)', 'Q', 'I', 'WEIGHTED_Z', 'P(WZ)', 'F0', 'F1', 'BETA', 'BETA(R)', 'SE', 'BETA_CONFINT_95_UPPER', 'BETA_CONFINT_95_LOWER', 'OR_CONFINT_95_UPPER', 'OR_CONFINT_95_LOWER', 'OR_SE','A1_MinorAlleleFreq', 'NCHROBS', 'rsID'


def threads_list_run(ThreadsList : list) -> None:
    """Runs all threads in a given list, waits till completion, then returns

    Args:
        * ThreadsList (list): A list of all the threads that need to be run till completion
    """
    for t in ThreadsList:
        t.start()   
    for t in ThreadsList:
        t.join()
    return




def convert_to_cojo(LogisticFilePath : str, PlinkMeta_True : bool = False) -> str:
    df = pd.read_csv(LogisticFilePath)
    return_df = pd.DataFrame()
    if PlinkMeta_True:
        # we are processing a meta-analysis output file from Plink
        samplesNumber = int(input("Enter the total number of samples in the meta-analysis\t:\t"))
        # return_df = df[['SNP','A1','A2','A1_MinorAlleleFreq','BETA','SE','P']]
        return_df = df[['SNP','A1_MinorAllele', 'A2_MajorAllele','A1_MinorAlleleFreq','BETA','SE','P']] # this is the case if the meta results file has been sorted and processed in order to add the freqs of alleles to it as well, so that it can actually be used
        return_df.columns = ['SNP', 'A1','A2','freq','b','se','p']
        return_df['N'] = samplesNumber
    else:
        # we are processing a plink logistic analysis result file
        return_df = df[['SNP','A1_MinorAllele', 'A2_MajorAllele', 'A1_MinorAlleleFreq','BETA','SE','P','NMISS']]
        return_df.columns = ['SNP', 'A1','A2','freq','b','se','p','N']
    return_df.to_csv(f"{LogisticFilePath}_For_ConditionalAnalysis.TabSep", sep="\t", index=False)
    return f"{LogisticFilePath}_For_ConditionalAnalysis.TabSep"

# get lead SNPs from a given file
def make_conditionalSNPs(Input_SNPlist_Path : str, OutputPath : str):
    df = pd.read_csv(Input_SNPlist_Path)
    SNP_rsIDs_True = bool
    SNP_rsIDs_True = bool((df["SNP"].str.contains("rs")).all()) # checking to see if all the rows in the SNP column contains the substring 'rs'
    rsIDs_dict, ChrBp_dict = dict(), dict()
    if SNP_rsIDs_True:
        l = list(df["SNP"])
        for f in l:
            outPath = f"{OutputPath}/SelectedSNP_rsID_{f}_ForConditional.txt"
            with open(outPath, "w") as wrt:
                wrt.write(f)
            rsIDs_dict[f] = outPath
    df["CHR_BP"] = df["CHR"].astype("str") + ":" + df["BP"].astype("str")
    l = list(df["CHR_BP"])
    for f in l:
        outPath = f"{OutputPath}/SelectedSNP_CHR-BP_{f}_ForConditional.txt"
        with open(outPath, "w") as wrt:
            wrt.write(f)
        ChrBp_dict[f] = outPath
    if SNP_rsIDs_True:
        return [ChrBp_dict,rsIDs_dict]
    else:
        return ChrBp_dict
    

# run conditional analysis
def run_conditional_analysis(gcta_path : str, bfile : str, cojoFile : str, chromosome_numbers : list, outputPath : str, SNPs_Selected : dict, maf : float = 0.005, window : int = 10000, collinearity : float = 0.9, diffFreq : float = 0.2) -> None:
    cmd=f"{gcta_path} --bfile {bfile} --thread-num 20 --cojo-file {cojoFile} --maf {maf} --cojo-wind {window} --cojo-collinear {collinearity} --diff-freq {diffFreq}"
    cmd_list = list()
    for snp, snp_path, chr_number in zip(list(SNPs_Selected.keys()), list(SNPs_Selected.values()), chromosome_numbers):
        cmd_outPart = f"--out {outputPath}/Conditional_{snp}"
        cmd_cojoCondPart = f"--cojo-cond {snp_path}"
        cmd_chrPart = f"--chr {chr_number}"
        newCmd_regular, newCmd_gc = cmd, cmd
        newCmd_regular += f" {cmd_chrPart} {cmd_outPart} {cmd_cojoCondPart}\n\n"
        cmd_outPart_GC = f"--out {outputPath}/Conditional_{snp}_GC"
        newCmd_gc += f" {cmd_chrPart} {cmd_outPart_GC} {cmd_cojoCondPart} --cojo-gc\n\n"
        cmd_list.append(newCmd_regular)
        cmd_list.append(newCmd_gc)
    with open(f"{outputPath}/Conditional_Commands.txt", "w") as wrt:
        wrt.writelines(cmd_list)
    input("The commands are stored in Press any key to proceed with command execution")
    with open(f"{outputPath}/Conditional_Commands.txt", "r") as rd:
        temp_cmd_list = list
        temp_cmd_list = rd.readlines()
        ThreadsList = list()
        for c in temp_cmd_list:
            ThreadObject = threading.Thread(target=os.system, kwargs={"command" : c})
            ThreadsList.append(ThreadObject)
            # os.system(c)
        threads_list_run(ThreadsList=ThreadsList)
    # for c in cmd_list:
    #     os.system(c)

# function takes in all the necessary inputs from the user
def get_inputs() -> dict:
    gcta = str(input("Enter the full path to the\tGCTA executeable\t:\t"))
    bfile = str(input("Enter the full path to the\tBED file set\t:\t"))
    # CojoSummary_ReadyTrue = bool
    # if input("Enter\tY\tif you already have a formatted summary statistics results file ready for conditional analysis\nEnter anything else to make one\t:\t") == "Y":
    #     CojoSummary_ReadyTrue = True
    # else:
    #     CojoSummary_ReadyTrue = False
    IsThisMeta = bool
    if input("Enter\tY\tif the summary results / logistic file is from a PLINK meta-analysis run\nElse, enter anything else\t:t") == "Y":
        IsThisMeta = True
    else:
        IsThisMeta = False
    cojo = str(input("Enter the full path to the\tLogistic / meta-analysis summary results CSV\t:\t"))
    outP = str(input("Enter the full path to the\toutput directory\t:\t"))
    chosenSNPs = str(input("Enter the full path to the .csv file that contains the SNP, CHR, BP columns of the SNPs that have to be processed for the conditional analysis\t:\t"))
    default_params = bool
    maf, window, collinearity, diffFreq = float,int, float, float
    if str(input("Enter\tY\t if you want the default values for the rest of the parameters\nElse enter anything else\t:\t")):
        default_params = True
    else:
        default_params = False
    if default_params == False:
        maf = input("Enter the value for the MAF filter\t(Default is 0.005)\t:\t")
        window = input("Enter the value for the LD window\t(Default is 10,000)\t:\t")
        collinearity = input("Enter the value for the collinearity check between SNPs\t(Default is 0.9)\t:\t")
        diffFreq = input("Enter the value for the difference in the allele freqs of SNPs between GWAS and LD reference\t(Default is 0.2)\t:\t")
    inputs_dict = dict()
    inputs_dict["gcta"] = gcta
    inputs_dict["bfile"] = bfile
    inputs_dict["cojo"] = cojo
    inputs_dict["OutputPath"] = outP
    inputs_dict["IsThisMeta"] = IsThisMeta
    inputs_dict['chosenSNPsPath'] = chosenSNPs
    inputs_dict['DefaultParams_True'] = default_params
    if default_params == True :
        return inputs_dict
    else:
        inputs_dict['maf'] = maf
        inputs_dict['window'] = window
        inputs_dict['collinearity'] = collinearity
        inputs_dict['diffFreq'] = diffFreq
        return inputs_dict
    

def process_conditional():
    user_inputs = get_inputs()
    cojoFilePath = convert_to_cojo(LogisticFilePath=user_inputs['cojo'], PlinkMeta_True=user_inputs['IsThisMeta'])
    SelectedSNPs_return = make_conditionalSNPs(Input_SNPlist_Path=user_inputs['chosenSNPsPath'], OutputPath=user_inputs['OutputPath'])
    chr_numbers = list
    selectedSNPsdict, selectedSNPsdict_ToPass = dict(), dict()
    if type(SelectedSNPs_return) == list:
        # this means that the BED BIM FAM have rsIDs
        selectedSNPsdict = dict(SelectedSNPs_return[0])
        selectedSNPsdict_ToPass = dict(SelectedSNPs_return[1])
    elif type(SelectedSNPs_return) == dict:
        selectedSNPsdict = SelectedSNPs_return
        selectedSNPsdict_ToPass = SelectedSNPs_return
    chr_bp = pd.Series(list(selectedSNPsdict.keys()))
    df = pd.DataFrame()
    df[["CHR", "BP"]] = chr_bp.str.split(":", expand=True)
    chr_numbers = list(df["CHR"].astype("int"))
    if user_inputs['DefaultParams_True'] == True:
        run_conditional_analysis(gcta_path=user_inputs['gcta'], bfile=user_inputs['bfile'],cojoFile=cojoFilePath,chromosome_numbers=chr_numbers,outputPath=user_inputs['OutputPath'], SNPs_Selected=selectedSNPsdict_ToPass)
    else:
        run_conditional_analysis(gcta_path=user_inputs['gcta'], bfile=user_inputs['bfile'],cojoFile=cojoFilePath,chromosome_numbers=chr_numbers,outputPath=user_inputs['OutputPath'], SNPs_Selected=selectedSNPsdict_ToPass, maf=user_inputs['maf'], window=user_inputs['window'],collinearity=user_inputs['collinearity'], diffFreq=user_inputs['diffFreq'])
        
process_conditional()