import pandas as pd
import threading
import os


def split_path_name(FullPath : str) -> list:
    """Given a full path to a file, returns the path to the folder, and the file name

    Args:
        FullPath (str): The full path to a file.

    Returns:
        list: A list containing the full path to the folder containing the file as the 0th element, and the file name as the 1st element.
    """
    PathElements = FullPath.split("/")
    FilePath = ""
    # reconstructing path to the folder
    for p in PathElements[1:len(PathElements)-1]:
        FilePath += f"/{p}"
    # getting the filename
    FileName = PathElements[len(PathElements)-1]
    return [FilePath, FileName]


def threads_list_run(ThreadsList : list) -> None:
    """Runs all threads in a given list, waits till completion, then returns

    Args:
        * ThreadsList (list): A list of all the threads that need to be run till completion
    """
    for t in ThreadsList:
        t.start()   
    for t in ThreadsList:
        t.join()
    return


def smr_preparation(DFPath : str) -> None:
    df = pd.read_csv(DFPath)
    cols = df.columns
    cols = cols.str.lower()
    df.columns = cols
    MinAllFreqColName = ""
    if "freq1" in list(cols):
        MinAllFreqColName = "freq1"
    else:
        MinAllFreqColName = "a1_minorallelefreq"
    Temp = df[["chr", "bp", "a1_minorallele", "a2_majorallele", MinAllFreqColName, "beta", "se", "p"]].copy(deep=True)
    Temp.columns = ["CHR", "BP", "A1_MinorAllele", "A2_MajorAllele", "A1_MinorAlleleFreq", "BETA", "SE", "P"]
    # Temp = df[["CHR", "BP", "A1_MinorAllele", "A2_MajorAllele", "A1_MinorAlleleFreq", "BETA", "SE", "P"]].copy(deep=True)
    print(Temp.head(3))
    FilePath, FileName = split_path_name(FullPath = DFPath)
    Temp.dropna(inplace=True)
    Temp[["CHR", "BP"]].info()
    Temp["CHR"] = Temp["CHR"].astype("str")
    Temp["BP"] = Temp["BP"].astype("str")
    Temp["SNP"] = Temp["CHR"] + ":" + Temp["BP"]
    Temp[["CHR", "BP", "SNP"]].info()
    Temp["n"] = "NA"
    Cols = pd.Series(Temp.columns)
    Cols = Cols.str.replace("A1_MinorAlleleFreq", "freq")
    Cols = Cols.str.replace("A1_MinorAllele", "A1")
    Cols = Cols.str.replace("A2_MajorAllele", "A2")
    Cols = Cols.str.replace("BETA", "b")
    Cols = Cols.str.replace("SE", "se") 
    #Cols = Cols.str.replace("P", "p")
    Temp.columns = Cols
    print(Temp.head(3))
    Temp.info()
    OutName = FileName.replace(".csv", "")
    print(OutName)
    Temp.sort_values(["CHR", "BP"], inplace=True)
    Temp[["SNP", "A1", "A2", "freq", "b", "se", "P", "n"]].to_csv(f"{FilePath}/{OutName}_Prepared_For_SMR.csv", index=False, sep="\t")
    del df
    del Temp
    return



FullLogistic_Paths = list()
EnterPaths = "Y"
while EnterPaths == "Y" or EnterPaths == "y":
    FilePath = str(input("Enter the path of full SORTED & cleaned FINAL CSV logistic file, with CSV extension\t:\t"))
    FullLogistic_Paths.append(FilePath)
    EnterPaths = str(input("Enter\t\"Y\"\t if you want to prepare more logistic files for SMR , else enter anything else\t:\t:"))


ThreadsList = list()
for p in FullLogistic_Paths:
    ThreadObject = threading.Thread(target=smr_preparation, kwargs={"DFPath" : p})
    ThreadsList.append(ThreadObject)

threads_list_run(ThreadsList=ThreadsList)
