import pandas as pd
import os
import time


def filter_snps(CHR_BP_List : list, BimFilePath : str, OutputPath : str) -> str:
    ExtractFilePath = f"{OutputPath}/SNPs_ToKeep.txt"
    BimFile = pd.read_csv(BimFilePath, header=None, sep="\s+")
    print(f"Finished reading the BIM file for getting the rsID or SNP ID that is in use\t:\t{BimFilePath}")
    BimFile.columns = ["CHR", "SNP", "Morgans", "BP", "A1", "A2"]
    SelectedSNPs_DF = pd.DataFrame()
    SelectedSNPs_List = list()
    for chr_bp in CHR_BP_List:
        chr_bp = str(chr_bp).replace("\n","")
        chr_bp = chr_bp.strip()
        chr = str(chr_bp).split(":")[0]
        bp = str(chr_bp).split(":")[1]
        #print(f"Reading the SNP on chromosome\t{chr}\tat bp position\t{bp}")
        chr = int(chr)
        bp = int(bp)
        BimFile["CHR"] = BimFile["CHR"].astype("int")
        BimFile["BP"] = BimFile["BP"].astype("int")
        SelectedSNPs = BimFile[(BimFile["CHR"] == chr) & (BimFile["BP"] == bp)]
        #print(SelectedSNPs)
        SelectedSNPs_List.append(SelectedSNPs)
    SelectedSNPs_DF = pd.concat(SelectedSNPs_List, ignore_index=True)
    TargetSNPs = SelectedSNPs_DF["SNP"]
    TargetSNPs_Str = ""
    for snp in TargetSNPs:
        TargetSNPs_Str += f"{snp}\n"
    with open(ExtractFilePath, "w") as WriteFile:
        WriteFile.write(TargetSNPs_Str)
    return ExtractFilePath


def filter_samples(SamplesList : list, OutputPath : str) -> str:
    KeepFilePath = f"{OutputPath}/Samples_ToKeep.txt"
    TargetSamples_str = ""
    for sample in SamplesList:
        sample = str(sample).replace("\n", "")
        sample = sample.strip()
        SampleAddString = f"{sample}\t{sample}"
        TargetSamples_str += f"{SampleAddString}\n"
    with open(KeepFilePath, "w") as WriteFile:
        WriteFile.write(TargetSamples_str)
    return KeepFilePath


def extract_snps_n_samples(ExtractionFile : str) -> list:
    TargetsList = list()
    with open(ExtractionFile, "r") as ReadFile:
        for Line in ReadFile:
            TargetsList.append(Line)
    return TargetsList
                
    
PlinkPath = str(input("Enter the path to plink executable\t:\t"))
BEDFilePath = str(input("Enter the full path to the BED fileset (preferably, post imputation merged file)\t:\t"))
OutputPath = str(input("Enter the path to the output folder\t:\t"))
SamplesFile_Path = str(input("Enter the path to a TXT file, where each line is a Sample ID of all the samples that are to be kept for the RAW file analysis\t:\t"))
SNPsFile_Path = str(input("Enter the path to a TXT file, where each line contains CHR:BP position (in that separation with a colon) of all the SNPs that are to be kept for the RAW file analysis\t:\t"))

SNPsList = extract_snps_n_samples(ExtractionFile=SNPsFile_Path)
SamplesList = extract_snps_n_samples(ExtractionFile=SamplesFile_Path)

SamplesKeepFile = filter_samples(SamplesList=SamplesList, OutputPath=OutputPath)
SNPsExtractFile = filter_snps(CHR_BP_List=SNPsList, BimFilePath=f"{BEDFilePath}.bim", OutputPath=OutputPath)

RawFilePath = f"{OutputPath}/RawFile_Samples_SNPs_Filtered"
RAWFileCommand = f"{PlinkPath} --bfile {BEDFilePath} --keep {SamplesKeepFile} --extract {SNPsExtractFile} --recode AD tabx include-alt --out {RawFilePath}"
os.system(RAWFileCommand)
Temp = input("Press any key after making sure that the RAW file has surely been created\t:\t")
RawFile = pd.read_csv(f"{RawFilePath}.raw", sep="\s+")
RawFile.fillna(value=-9, inplace=True)
RawFile.to_csv(f"{RawFilePath}.csv", index=False)

ColumnNames = list(RawFile.columns)
NewColumnNames = ["FID", "IID", "PAT", "MAT", "SEX", "PHENOTYPE"]
for c in NewColumnNames:
    ColumnNames.remove(c)
AllelicRAWFile = RawFile.copy(deep=True)
for col in ColumnNames:
    AllelicRAWFile[col] = AllelicRAWFile[col].astype("str")
    AllelicRAWFile[col] = AllelicRAWFile[col].astype("float")
    AllelicRAWFile[col] = AllelicRAWFile[col].astype("int")
    # the above line to make sure that comparisons are taking place between two ints, and not 
    NewColname = ""
    if "HET" in str(col):
        NewColname = f"{VariantID}-HET-or-NOT"
    else:
        Temp = col.split("_")
        VariantID = Temp[0]
        Parts = str(Temp[1]).split("(/")
        CountedAllele = Parts[0]
        AlternateAllele = str(Parts[1]).replace(")", "")
        NewColname = f"{VariantID}-CountedAllele_{CountedAllele}-AlternateAllele_{AlternateAllele}"
        AllelicRAWFile.loc[AllelicRAWFile[col] == 1, col] = f"{CountedAllele}{AlternateAllele}"
        AllelicRAWFile.loc[AllelicRAWFile[col] == 2, col] = f"{CountedAllele}{CountedAllele}"
        AllelicRAWFile.loc[AllelicRAWFile[col] == 0, col] = f"{AlternateAllele}{AlternateAllele}"
        AllelicRAWFile.loc[AllelicRAWFile[col] == -9, col] = f"MISSING"
    NewColumnNames.append(NewColname)
    # now to prettify the copied dataframe such that instead of the count of the alleles the letters are shown in the column
    #AllelicRAWFile[AllelicRAWFile.loc[:,col] == 1][col] = f"{CountedAllele}{AlternateAllele}"
    #AllelicRAWFile[AllelicRAWFile.loc[:,col] == 2][col] = f"{CountedAllele}{CountedAllele}"
    #AllelicRAWFile[AllelicRAWFile.loc[:,col] == 0][col] = f"{AlternateAllele}{AlternateAllele}"
    
    #AllelicRAWFile[AllelicRAWFile[col] == 1][col] = f"{CountedAllele}{AlternateAllele}"
    #AllelicRAWFile[AllelicRAWFile[col] == 2][col] = f"{CountedAllele}{CountedAllele}"
    #AllelicRAWFile[AllelicRAWFile[col] == 0][col] = f"{AlternateAllele}{AlternateAllele}"
    
    ############# 
    ############# THIS IS THE ONE THAT WORKS !! 
    #AllelicRAWFile.loc[AllelicRAWFile[col] == 1, col] = f"{CountedAllele}{AlternateAllele}"
    #AllelicRAWFile.loc[AllelicRAWFile[col] == 2, col] = f"{CountedAllele}{CountedAllele}"
    #AllelicRAWFile.loc[AllelicRAWFile[col] == 0, col] = f"{AlternateAllele}{AlternateAllele}"
    #AllelicRAWFile.loc[AllelicRAWFile[col] == -9, col] = f"MISSING"
    
    ############
    ############
    
    #AllelicRAWFile[AllelicRAWFile[col] == "1"][col] = f"{CountedAllele}{AlternateAllele}"
    #AllelicRAWFile[AllelicRAWFile[col] == "2"][col] = f"{CountedAllele}{CountedAllele}"
    #AllelicRAWFile[AllelicRAWFile[col] == "0"][col] = f"{AlternateAllele}{AlternateAllele}"

RawFile.columns = NewColumnNames
RawFile.to_csv(f"{RawFilePath}_ClearHeaders.csv", index=False)
AllelicRAWFile.columns = NewColumnNames
AllelicRAWFile.to_csv(f"{RawFilePath}_ClearHeaders_Bases.csv", index=False)


