import pandas as pd
from scipy.stats import norm
import math
import os
import threading
import time

ColumnNamesDict = dict({"BETA" : ["BETA","BE","B","Log(OR)"], "SE" : ["SE","Standard Error","StandardError"], "OR" : ["OR","ODDS","ODDSRATIO","Odds Ratio"], "P" : ["P", "PVal", "P Value", "P-Value"]})
print("This script, will detect columns based on the following names\tCASE INSENSITIVE\t:\n\n1) Effect Size (regression coefficient) (effect estimate) (beta estimate)\t:\t")
print(ColumnNamesDict["BETA"])
print("\n2) Odds Ratio\t:\t")
print(ColumnNamesDict["OR"])
print("\n3) Standard Error Standard error of beta estimate\t:\t")
print(ColumnNamesDict["SE"])
time.sleep(5)

def split_path_name(FullPath : str) -> list:
    """Given a full path to a file, returns the path to the folder, and the file name

    Args:
        FullPath (str): The full path to a file.

    Returns:
        list: A list containing the full path to the folder containing the file as the 0th element, and the file name as the 1st element.
    """
    PathElements = FullPath.split("/")
    FilePath = ""
    # reconstructing path to the folder
    for p in PathElements[1:len(PathElements)-1]:
        FilePath += f"/{p}"
    # getting the filename
    FileName = PathElements[len(PathElements)-1]
    return [FilePath, FileName]


def read_any_separator_df(PathToDataFrame : str) -> pd.DataFrame :
        # CommaSep, SpaceSep, TabSep = False, False, False
        df = pd.read_csv(PathToDataFrame, sep=",", nrows = 10)
        if len(list(df.columns)) > 1:
            print("Comma Separated File")
            df = pd.DataFrame()
            df = pd.read_csv(PathToDataFrame, sep=",")
            return df
        if len(list(df.columns)) == 1:
            df = pd.DataFrame()
            df = pd.read_csv(PathToDataFrame, sep="\s+", nrows=10)
            df2 = pd.DataFrame()
            df2 = pd.read_csv(PathToDataFrame, sep="\t", nrows=10)
            if len(list(df2.columns)) == 1:
                print("Space Separated File 1")
                df = pd.DataFrame()
                df = pd.read_csv(PathToDataFrame, sep="\s+")
                return df
            elif len(list(df.columns)) >= len(list(df2.columns)) and ~(len(list(df2.columns)) == 1):
                print("Tab Separated File 1")
                df2 = pd.DataFrame()
                df2 = pd.read_csv(PathToDataFrame, sep="\t")
                return df2
            else:
                pass


def column_found_in_list(ColumnsNamesToSearchFor : list, ColumnsFromTable : list) -> list:
    KeyWords = list(pd.Series(ColumnsNamesToSearchFor).str.lower())
    print(KeyWords)
    Found = bool
    FoundName = ""
    for ColName in ColumnsFromTable:
        print(ColName)
        print(f"searchjing for\t:")
        print(str(ColName).lower())
        if str(ColName).lower() in KeyWords:
            Found = True
            FoundName = ColName
            break
        else:
            Found = False
            continue
    return [Found, FoundName]


def threads_list_run(ThreadsList : list) -> None:
    """Runs all threads in a given list, waits till completion, then returns

    Args:
        * ThreadsList (list): A list of all the threads that need to be run till completion
    """
    for t in ThreadsList:
        t.start()   
    for t in ThreadsList:
        t.join()
    return


def calculate_se(DF : pd.DataFrame, beta : str, Pfound : bool, pvalue : str) -> pd.DataFrame:
    print("SE column will be made using the BETA co-eff values")
    if Pfound == False:
        print("BUT, P values will be required, which are not found in this file. Thus aborting the process.")
        exit()
    else:
        DF[beta] = DF[beta].astype("float")
        DF[pvalue] = DF[pvalue].astype("float")
        seList = list()
        for p, b in zip(list(DF[pvalue]), list(DF[beta])):
            seTemp = abs(b/norm.ppf(p/2))
            seList.append(seTemp)
        DF["se"] = pd.Series(seList)
    return DF


def calculate_beta(DF : pd.DataFrame, ORFound : bool, ORName : str) -> pd.DataFrame:
    print("BETA column will be made using the OR Odds Ratio values")
    if ORFound == False:
        print("BUT, OR values will be required, which are not found in this file. Thus aborting the process.")
        exit()
    else:
        DF[ORName] = DF[ORName].astype("float")
        bList = list()
        for odds in list(DF[ORName]):
            bTemp = round(math.log(odds), 6)
            bList.append(bTemp)
        DF["beta"] = pd.Series(bList)
    return DF

def calculate_or(DF : pd.DataFrame, betaFound : bool, beta : str) -> pd.DataFrame:
    print("OR column will be made using the BETA values")
    if betaFound == False:
        print("BUT, BETA values will be required, which are not found in this file. Thus aborting the process.")
        exit()
    else:
        DF[beta] = DF[beta].astype("float")
        orList = list()
        for b in DF[beta]:
            oddsTemp = math.pow(2.718281828,b)
            orList.append(oddsTemp)
        DF["or"] = pd.Series(orList)
    return DF


def get_ConfIntervals(df : pd.DataFrame, beta : str, se : str) -> pd.DataFrame:
    print("Confidence intervals and SE for BETA and OR column will be made using the BETA & BETA SE values")
    Beta = df[beta]
    Beta_SE = df[se]
    Beta_SE_1_96 = Beta_SE * 1.96
    Beta_ConfInt_95_Upper = Beta + Beta_SE_1_96
    Beta_ConfInt_95_Lower = Beta - Beta_SE_1_96
    OR_ConfInt_95_Upper, OR_ConfInt_95_Lower, OR_SE = list(), list(), list()
    for beta_ul, beta_ll in zip(Beta_ConfInt_95_Upper, Beta_ConfInt_95_Lower):
        e_value = 2.71828
        or_ul = math.pow(e_value, beta_ul)
        or_ll = math.pow(e_value, beta_ll)
        or_difference = or_ul - or_ll
        or_se = or_difference * 3.92
        OR_ConfInt_95_Upper.append(or_ul)
        OR_ConfInt_95_Lower.append(or_ll)
        OR_SE.append(or_se)
    df["beta_confint_95_upper"] = Beta_ConfInt_95_Upper
    df["beta_confint_95_lower"] = Beta_ConfInt_95_Lower
    df["or_confint_95_upper"] = OR_ConfInt_95_Upper
    df["or_confint_95_lower"] = OR_ConfInt_95_Lower
    df["or_se"] = OR_SE
    return df



def manage_additional_stats(InputFileFullPath : str) -> None:
    PathToFile = InputFileFullPath
    FilePath, FileName = split_path_name(FullPath=InputFileFullPath)
    DF = read_any_separator_df(PathToDataFrame=PathToFile)
    ColumnNames = list(pd.Series(list(DF.columns)).str.lower())
    DF.columns = ColumnNames
    BETAFound, BETAColName = column_found_in_list(ColumnsNamesToSearchFor=list(ColumnNamesDict["BETA"]), ColumnsFromTable=ColumnNames)
    ORFound, ORColName = column_found_in_list(ColumnsNamesToSearchFor=list(ColumnNamesDict["OR"]), ColumnsFromTable=ColumnNames)
    SEFound, SEColName = column_found_in_list(ColumnsNamesToSearchFor=list(ColumnNamesDict["SE"]), ColumnsFromTable=ColumnNames)
    PFound, PColName = column_found_in_list(ColumnsNamesToSearchFor=list(ColumnNamesDict["P"]), ColumnsFromTable=ColumnNames)
    if BETAFound == True and ORFound == True and SEFound == True:
        print(f"All three columns already exist in the file\t:\t{FileName} in the location\t:\t{FilePath}")
        DF = get_ConfIntervals(df = DF, beta=BETAColName, se=SEColName)
        ColumnNames = list(pd.Series(list(DF.columns)).str.upper())
        DF.columns = ColumnNames
        DF.to_csv(f"{FilePath}/{FileName}_With_BETA-SE-OR_n_ConfIntervals_95.csv", index=False)
        DF.to_csv(f"{FilePath}/{FileName}_With_BETA-SE-OR_n_ConfIntervals_95_TABSep", index=False, sep="\t")
        print(f"Done adding stats columns to file named\t:\t{FileName} in the location\t:\t{FilePath}")
        return
    if BETAFound == True:
        if ORFound == False:
            DF = calculate_or(DF=DF, betaFound=BETAFound, beta=BETAColName)
            ORFound = True
            ORColName = "or"
    elif ORFound == True:
        if BETAFound == False:
            DF = calculate_beta(DF=DF, ORFound=ORFound, ORName=ORColName)
            BETAFound = True
            BETAColName = "beta"
    if BETAFound == True and SEFound == False:
        DF = calculate_se(DF=DF, beta=BETAColName, Pfound=PFound, pvalue=PColName)
        SEFound = True
        SEColName = "se"
    DF = get_ConfIntervals(df = DF, beta=BETAColName, se=SEColName)
    ColumnNames = list(pd.Series(list(DF.columns)).str.upper())
    DF.columns = ColumnNames
    DF.to_csv(f"{FilePath}/{FileName}_With_BETA-SE-OR_n_ConfIntervals_95.csv", index=False)
    DF.to_csv(f"{FilePath}/{FileName}_With_BETA-SE-OR_n_ConfIntervals_95_TABSep", index=False, sep="\t")
    print(f"Done adding stats columns to file named\t:\t{FileName} in the location\t:\t{FilePath}")
    return


InputFilePaths = list()
EnterPaths = "Y"
while EnterPaths == "Y" or EnterPaths == "y":
    FilePath = str(input("Enter the full path to the file having any or all \n\tBETA coefficient (log odds ratio), Standard Error of BETA, or Odds Ratio\t:\t"))
    InputFilePaths.append(FilePath)
    EnterPaths = str(input("Enter\t\"Y\"\t if you want to prepare more files for additional stats columns, else enter anything else\t:\t:"))
ThreadsList = list()
for p in InputFilePaths:
    ThreadObject = threading.Thread(target=manage_additional_stats, kwargs={"InputFileFullPath" : p})
    ThreadsList.append(ThreadObject)

threads_list_run(ThreadsList=ThreadsList)


# if BETAFound == True:
#     if ORFound == True:
#         if SEFound == True:
#             print("The Dataframe has all three columns")
#         else:
#             DF = calculate_se(DF=DF, beta=BETAColName, Pfound=PFound, pvalue=PColName)
#             SEFound = True
#             SEColName = "se"
#     else:
#         DF = calculate_or(DF=DF, betaFound=BETAFound, beta=BETAColName)
#         ORFound = True
#         ORColName = "or"

# if ORFound == True:
#     if BETAFound == False:
#         DF = calculate_beta(DF=DF, ORFound=ORFound, ORName=ORColName)
#         BETAFound = True
#         BETAColName = "beta"
#         if SEFound == True:
#             print("The Dataframe has all three columns")
#         else:
#             DF = calculate_se(DF=DF, beta=BETAColName, Pfound=PFound, pvalue=PColName)
#             SEFound = True
#             SEColName = "se"


