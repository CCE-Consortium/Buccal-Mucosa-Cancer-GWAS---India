import pandas as pd
path = str(input("Enter the path to the folder : "))
name = str(input("Enter the name of input file : "))
outName = str(input("Enter name of output file : "))
TopSNPNum = int(input("Enter the number of top SNPs you want in the output\t:\t"))
df = pd.read_csv(f"{path}/{name}", sep="\s+")

df = df.dropna()
df = df.sort_values("P")
newdf = df.nsmallest(TopSNPNum, "P", "all")
df.to_csv(f"{path}/{outName}.csv", index=False)

# convergingh with th einfor file over here

newdf.to_csv(f"{path}/{outName}_Top{TopSNPNum}snps.csv", index=False)
print("\nP vals of full result :\n")
print(df["P"].describe())
print("\nP vals of top result :\n")
print(newdf["P"].describe())
print("\nResult : \n")
print(newdf.head(5))
ImpScoresFile = str(input("Enter the path to the merged full info scores file :\n"))
InfoDf = pd.read_csv(ImpScoresFile)
ResultDf = pd.merge(newdf, InfoDf, on=["CHR","BP"])
ResultDf.to_csv(f"{path}/{outName}_Top{TopSNPNum}snps_with_Infoscores.csv", index=False)
FullResultDf = pd.merge(df, InfoDf, on=["CHR","BP"])
FullResultDf.to_csv(f"{path}/{outName}_Full_with_InfoScores.csv", index=False)
