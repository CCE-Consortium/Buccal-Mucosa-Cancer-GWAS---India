import pandas as pd
import os

"""
This script automates the generation of R script commands for creating a wide variety of PCA (Principal Component Analysis) plots using ggplot2 in R. 
It allows users to interactively select plot types, specify relevant data columns, and generate R scripts that visualize PCA results with customizable aesthetics (color, shape, border, etc.) based on sample metadata.

Summary:
------------
- Presents a menu of PCA plot types and collects user selections.
- Prompts for all necessary user inputs (data file path, column names, plot title, output directory, etc.) based on selected plot types.
- Dynamically generates R script commands for all combinations of selected plot types, PC axes, shape encodings, and axis reversal options.
- Organizes output R script and plot files in structured directories.
- Supports advanced plot customizations: color by region/state/gender, shape by phenotype, border thickness/color by gender, etc.

Args:
------------
- No direct function arguments for the main script execution.
- Key functions and their arguments:
  - `select_pca_plots()`
    - No arguments.
  - `pca_plot_inputs(types_of_pca: list)`
    - `types_of_pca` (`list`): List of selected PCA plot type integers.
  - `get_directories(BaseOutputDir: str, pca_choice: int, shapes_combo: str)`
    - `BaseOutputDir` (`str`): Base output directory path.
    - `pca_choice` (`int`): Selected PCA plot type.
    - `shapes_combo` (`str`): Shape combination name.
  - `pca_plot_standard(ReturnType: str)`
    - `ReturnType` (`str`): "Normal", "ReverseX", "ReverseY", or "ReverseBoth".
  - `command_differentiator(...)`
    - Multiple arguments for plot configuration (see function for details).

Returns:
------------
- Main script writes an R script file to the specified output directory.
- `select_pca_plots()`:
  - `list`: List of integers representing selected PCA plot types.
- `pca_plot_inputs()`:
  - `dict`: Dictionary with the following keys and value types:
    - `FilePath` (`str`): Path to the CSV file with PCA data.
    - `Phenotype` (`str`): Column name for case-control status.
    - `Title` (`str`): Plot title.
    - `OutputDir` (`str`): Output directory path.
    - `Gender` (`str`): Column name for gender (empty string if not used).
    - `States` (`str`): Column name for states (empty string if not used).
    - `Regions` (`str`): Column name for regions (empty string if not used).
- `get_directories()`:
  - `str`: Full path to the output directory for the given plot type and shape combination.
- `pca_plot_standard()`:
  - `str`: R command string for standardized plot theme or axis reversal.
- `command_differentiator()`:
  - `str`: R ggplot command string for the specified plot type and configuration.

Exceptions:
------------
- `select_pca_plots()`:
  - May raise `ValueError` if user input cannot be converted to integers.
- `pca_plot_inputs()`:
  - May raise `FileNotFoundError` if the specified CSV file does not exist.
  - May raise `pandas.errors.EmptyDataError` if the CSV file is empty.
- `pca_plot_standard()`:
  - Prints a warning if an invalid `ReturnType` is provided.
- Main script:
  - May raise file I/O errors when writing output files.
  - May raise `KeyError` if expected dictionary keys are missing due to incomplete user input.

Example usages:
------------
>>> # Example 1: Select plot types and collect inputs
>>> plot_types = select_pca_plots()
Which types of PCA plots do you want: 
Type 1: Coloured regions with the phenotype as shapes
Type 2: Coloured regions with the phenotype as shapes & gender as border thickness
...
Enter the number corresponding to the types of plots you want, SEPARATED BY A COMMA like 1,2,3 etc: 1,3,5
>>> print(plot_types)
[1, 3, 5]

>>> # Example 2: Collect plot configuration inputs
>>> input_dict = pca_plot_inputs([1, 2, 4])
Enter the full path to the .CSV file that contains the PCA, the Case-Control status and if available, the regions, states & gender of the samples: /path/to/data.csv
...
>>> print(input_dict["Phenotype"])
'CaseControlStatus'

>>> # Example 3: Generate standard R theme command
>>> theme_cmd = pca_plot_standard("Normal")
>>> print(theme_cmd[:30])
theme_classic() + theme(axis.t

>>> # Example 4: Get output directory for a specific plot type and shape
>>> out_dir = get_directories("/output/path", 1, "Circle-Diamond")
>>> print(out_dir)
/output/path/Region_Pheno/Circle-Diamond

Notes:
------------
- The generated R script will be saved as `R_ggplots_commands.r` in the specified output directory.
- The script supports up to 10 principal components (PC1 to PC10) and all pairwise combinations.
- Shape and color encodings are customizable for each plot type.
- The script assumes that the user will define color variables (`colours_regions`, `colours_states`, `colours_genders`) in the R environment before running the script.
- The script prints the final R script path and the command to execute it using `Rscript`.

"""


# this code creates R scripts for plotting PCA plots of different types :
    # PCA with colours as regions and case controls as shape
    # Above + Border thickness as Gender
    # PCA with colours as states and case controls as shape
    # Above + Border thickness as Gender
    # PCA with colours as case control status, and shape as gender


# decide which types of PCA plots we might need here : (based on data and expected / desired output)
def select_pca_plots() -> list:
    """
    Presents users with different PCA plot options and collects their choices.

    Summary:
    ------------
    - Displays a menu of 7 PCA plot types, each combining color, shape, and border visual encodings.
    - Prompts the user to select one or more plot types by entering their corresponding numbers.
    - Returns a list of integers representing the selected plot types.

    Returns:
    ------------
    - `list`: List of integers, each representing a selected PCA plot type.

    Exceptions:
    ------------
    - May raise `ValueError` if user input contains non-integer values.

    Examples:
    ------------
    >>> choices = select_pca_plots()
    Which types of PCA plots do you want:
    Type 1: Coloured regions with the phenotype as shapes
    Type 2: Coloured regions with the phenotype as shapes & gender as border thickness
    ...
    Enter the number corresponding to the types of plots you want, SEPARATED BY A COMMA like 1,2,3 etc: 1,3,5
    >>> print(choices)
    [1, 3, 5]
    """
    plot_types = {
        1 : "Coloured regions with the phenotype as shapes",
        2 : "Coloured regions with the phenotype as shapes & gender as border thickness",
        3 : "Coloured regions with the phenotype as shapes & gender as border colour",
        4 : "Coloured regions with states inside a region of nearby shades of colours, phenotype as shapes",
        5 : "Coloured regions with states inside a region of nearby shades of colours, phenotype as shapes & gender as border thickness",
        6 : "Coloured regions with states inside a region of nearby shades of colours, phenotype as shapes & gender as border colour",
        7 : "Coloured gender with phenotype as shapes"
    }
    choices = list()
    print("Which types of PCA plots do you want\t:\t")
    for key_val_list in plot_types.items():
        print(f"Type\t{key_val_list[0]}\t:\t{key_val_list[1]}")
    plot_choices_input = str(input("\nEnter the number corresponding to the types of plots you want, SEPARATED BY A COMMA like 1,2,3 etc\t:\t"))
    plot_choices_input = plot_choices_input.strip()
    for element in list(plot_choices_input.split(",")):
        choices.append(int(element))
    return choices


def pca_plot_inputs(types_of_pca : list) -> dict:
    """
    Collects user inputs for PCA plot generation based on selected plot types.
    
    Summary:
    ------------
    This function prompts the user for various inputs needed to generate the selected PCA plots,
    including the path to the CSV file containing PCA data, column names for case-control status,
    regions, states, gender, plot title, and output directory. It dynamically requests only the
    inputs relevant to the selected plot types.
    
    Args:
    ------------
    - `types_of_pca` (`list`): List of integers representing the selected PCA plot types
    
    Returns:
    ------------
    - `dict`: A dictionary containing all the user inputs with the following keys:
      * `FilePath`: Path to the CSV file with PCA data
      * `Phenotype`: Column name for case-control status
      * `Title`: Plot title
      * `OutputDir`: Base output directory path
      * `Gender`: Column name for gender (empty string if not applicable)
      * `States`: Column name for states (empty string if not applicable)
      * `Regions`: Column name for regions (empty string if not applicable)
    
    Exceptions:
    ------------
    - May raise `FileNotFoundError` if the specified CSV file doesn't exist
    - May raise `pd.errors.EmptyDataError` if the CSV file is empty
    
    Examples:
    ------------
    >>> input_dict = pca_plot_inputs([1, 2, 4])
    Enter the full path to the .CSV file that contains the PCA, the Case-Control status and if available, the regions, states & gender of the samples: /path/to/data.csv
    ...
    >>> print(input_dict["Phenotype"])
    'CaseControlStatus'
    """
    # this function intakes names of the columns on the basis of the choices that have been taken by the user :
    # it takes as a parameter, the list of choices that the user has taken for the types of PCA plots that the user wants
    df_fullPath = str(input("Enter the full path to the .CSV file that contains the PCA, the Case-Control status and if available, the regions, states & gender of the samples\t:\t"))
    df = pd.read_csv(df_fullPath, nrows=10)
    print(df.head(4))
    print(list(df.columns))
    CaseControlStatusName = str(input("Enter the name of the column which contains the case control status of the samples\t:\t"))
    PlotTitle = str(input("Enter the plot title\t:\t"))
    BaseOutputDir = str(input("Enter the base path to the directory where all the outputs will go to\t:\t"))
    GenderCol, StatesCol, RegionsCols = "", "", ""
    if 2 in types_of_pca or 5 in types_of_pca or 6 in types_of_pca or 7 in types_of_pca:
        GenderCol = str(input("Enter the name of the column that contains the gender of the samples. If it is integer format, for ex: 1 for Males 2 for Females etc, then that is how it will be shown in the legend. THEREFORE, better to provide a gender column that contains the values in words\t:\t"))
    if 1 in types_of_pca or 2 in types_of_pca or 3 in types_of_pca:
        RegionsCols = str(input("Enter the name of the column which contains the regions information for samples\t:\t"))
    if 4 in types_of_pca or 5 in types_of_pca or 6 in types_of_pca:
        StatesCol = str(input("Enter the name of the column which contains the birth state information for samples\t:\t"))
    input_dict = {
        "FilePath" : df_fullPath,
        "Phenotype" : CaseControlStatusName,
        "Title" : PlotTitle,
        "OutputDir" : BaseOutputDir,
        "Gender" : GenderCol,
        "States" : StatesCol,
        "Regions" : RegionsCols
    }
    return input_dict
        

def get_directories(BaseOutputDir : str, pca_choice : int, shapes_combo : str) -> str:
    """
    Creates and returns an output directory path for a specific PCA plot type and shape combination.

    Summary:
    ------------
    - Determines the subdirectory name based on the plot type (e.g., "Region_Pheno", "States_Pheno_Gender-BordThick").
    - Constructs the full output directory path by combining the base directory, plot type, and shape combination.
    - Creates the directory if it does not already exist.

    Args:
    ------------
    - `BaseOutputDir` (`str`): Base output directory path.
    - `pca_choice` (`int`): Integer representing the selected PCA plot type.
    - `shapes_combo` (`str`): Name of the shape combination (e.g., "Circle-Diamond").

    Returns:
    ------------
    - `str`: Full path to the output directory for the given plot type and shape combination.

    Exceptions:
    ------------
    - May raise `OSError` if the directory cannot be created (e.g., due to permissions).

    Examples:
    ------------
    >>> out_dir = get_directories("/output/path", 1, "Circle-Diamond")
    >>> print(out_dir)
    /output/path/Region_Pheno/Circle-Diamond
    """
    
    type_directory = ""
    if pca_choice == 1:
        type_directory = "Region_Pheno"
    elif pca_choice == 2:
        type_directory = "Region_Pheno_Gender-BordThick"
    elif pca_choice == 3:
        type_directory = "Region_Pheno_Gender-BordCol"
    elif pca_choice == 4:
        type_directory = "States_Pheno"
    elif pca_choice == 5:
        type_directory = "States_Pheno_Gender-BordThick"
    elif pca_choice == 6:
        type_directory = "States_Pheno_Gender-BordCol"
    elif pca_choice == 7:
        type_directory = "Gender_Pheno"
    OutputDirectory = f"{BaseOutputDir}/{type_directory}/{shapes_combo}"
    # Create the base output directory if it doesn't exist
    if not os.path.exists(OutputDirectory):
        os.makedirs(OutputDirectory)
    return OutputDirectory
        
   
# call this method to get a string of text that will be appended to the R script file from time to time
def pca_plot_standard(ReturnType : str) -> str:
    """
    Provides standard R command components for PCA plot generation.

    Summary:
    ------------
    - Returns common R ggplot2 theme and axis scaling commands as strings.
    - Used to standardize the look and axis orientation of all PCA plots.

    Args:
    ------------
    - `ReturnType` (`str`): Specifies which command component to return.
        * "Normal": Returns the standard ggplot2 theme.
        * "ReverseX": Returns the command to reverse the y-axis.
        * "ReverseY": Returns the command to reverse the x-axis.
        * "ReverseBoth": Returns the command to reverse both axes.

    Returns:
    ------------
    - `str`: The requested R command component as a string.

    Exceptions:
    ------------
    - Prints a warning if an invalid `ReturnType` is provided and returns a default error string.

    Examples:
    ------------
    >>> common = pca_plot_standard("Normal")
    >>> print(common[:30])
    theme_classic() + theme(axis.t

    >>> reverse_both = pca_plot_standard("ReverseBoth")
    >>> print(reverse_both)
    scale_y_reverse() + scale_x_reverse()
    """
    # this function intakes names of the columns & creates basic command structures
    # these are things that are common for all the PCA plot R command, 
    # time for the input
    common_cmd = "theme_classic() + theme(axis.text = element_text(size=30), axis.title = element_text(size=30, face = \"bold\"), plot.title = element_text(size=38, face = \"bold\", hjust = 0.5, vjust = -5), , legend.text = element_text(size=35), legend.spacing.x = unit(1,\"cm\"), legend.spacing.y = unit(0.5,\"cm\"), legend.position = \"right\", legend.background = element_rect(color = \"transparent\", fill=\"transparent\"), legend.title = element_blank(), legend.key = element_rect(color = \"transparent\", fill=\"transparent\"), panel.grid.major = element_line(linetype = \"solid\", color = \"#FFFFF099\"), panel.border = element_blank(), panel.grid.minor = element_blank()) + guides(fill = guide_legend(byrow = TRUE))"
    # now for taking column name inputs
    ReverseScale_X, ReverseScale_Y, ReverseScale_XY = "scale_y_reverse()", "scale_x_reverse()", "scale_y_reverse() + scale_x_reverse()"
    # by this point, the necessary input columns that are needed for the types of PCA's that we have selected, have been input from the user :
    if ReturnType == "Normal" :
        return common_cmd
    elif ReturnType == "ReverseX" :
        return ReverseScale_X
    elif ReturnType == "ReverseY" :
        return ReverseScale_Y
    elif ReturnType == "ReverseBoth" :
        return ReverseScale_XY
    else:
        print(ReturnType)
        return "Some incorrect argument value was passed to this function\nPlease take note"
    

def command_differentiator(pca_choice : int, x : str, y : str, Phenotype : str, Title : str, Gender : str, States : str, Regions : str, shape_number : str) -> str:
    """
    Generates the R ggplot2 command string for a specific PCA plot type and configuration.

    Summary:
    ------------
    - Constructs the ggplot2 command based on the selected PCA plot type, principal components, and aesthetic mappings.
    - Handles color, shape, fill, and border encodings for regions, states, gender, and phenotype.
    - Supports all plot types as defined in the script.

    Args:
    ------------
    - `pca_choice` (`int`): Integer representing the selected PCA plot type.
    - `x` (`str`): Name of the principal component for the x-axis (e.g., "PC1").
    - `y` (`str`): Name of the principal component for the y-axis (e.g., "PC2").
    - `Phenotype` (`str`): Column name for case-control status.
    - `Title` (`str`): Plot title.
    - `Gender` (`str`): Column name for gender.
    - `States` (`str`): Column name for states.
    - `Regions` (`str`): Column name for regions.
    - `shape_number` (`str`): Shape code(s) for ggplot2.

    Returns:
    ------------
    - `str`: The complete R ggplot2 command string for the specified configuration.

    Exceptions:
    ------------
    - No explicit exceptions raised, but may produce invalid R code if required arguments are missing or incorrect.

    Examples:
    ------------
    >>> cmd = command_differentiator(
    ...     pca_choice=1,
    ...     x="PC1",
    ...     y="PC2",
    ...     Phenotype="CaseControlStatus",
    ...     Title="My PCA Plot",
    ...     Gender="Gender",
    ...     States="",
    ...     Regions="Region",
    ...     shape_number="19,18"
    ... )
    >>> print(cmd[:30])
    ggplot(pca, aes(x=PC1, y=PC2
    """
    cmd = f"ggplot(pca, aes(x={x}, y={y})) + "
    # ggplot(pca, aes(x=PC1, y=PC2)) + geom_point(aes(color = factor(POB_state_2_1), shape = Phen), size=7) + scale_shape_manual(values = c(19,18)) + scale_colour_manual(values = colours) + labs(title = "GBC-2_StateWise_PCA")
    if pca_choice == 1:
        # "Region_Pheno"
        cmd += f"geom_point(aes(color = factor({Regions}), shape = {Phenotype}), size=7) + scale_shape_manual(values = c({shape_number})) + scale_colour_manual(values = colours_regions) + labs(title = \"{Title}\")"
    elif pca_choice == 2:
        # "Region_Pheno_Gender-BordThick"
        cmd += f"geom_point(aes(color = factor({Regions}), shape = {Phenotype}, stroke = ifelse({Gender} == \"Female\", 2, 1)), size=7) + scale_shape_manual(values = c({shape_number})) + scale_colour_manual(values = colours_regions) + labs(title = \"{Title}\")"
    elif pca_choice == 3:
        # "Region_Pheno_Gender-BordCol"
        cmd += f"geom_point(aes(fill = factor({Regions}), color = factor({Gender}), shape = {Phenotype}, stroke = ifelse({Gender} == \"Female\", 2, 1)), size=7) + scale_shape_manual(values = c({shape_number})) + scale_fill_manual(values = colours_regions) + scale_color_manual(values = c(\"#CDC9C900\", \"#030303\", \"#9370DB\")) + labs(title = \"{Title}\")"
    elif pca_choice == 4:
        # "States_Pheno"
        cmd += f"geom_point(aes(color = factor({States}), shape = {Phenotype}), size=7) + scale_shape_manual(values = c({shape_number})) + scale_colour_manual(values = colours_states) + labs(title = \"{Title}\")"
    elif pca_choice == 5:
        # "States_Pheno_Gender-BordThick"
        cmd += f"geom_point(aes(color = factor({States}), shape = {Phenotype}, stroke = ifelse({Gender} == \"Female\", 2, 1)), size=7) + scale_shape_manual(values = c({shape_number})) + scale_colour_manual(values = colours_states) + labs(title = \"{Title}\")"
    elif pca_choice == 6:
        # "States_Pheno_Gender-BordCol"
        cmd += f"geom_point(aes(fill = factor({States}), color = factor({Gender}), shape = {Phenotype}, stroke = ifelse({Gender} == \"Female\", 2, 1)), size=7) + scale_shape_manual(values = c({shape_number})) + scale_fill_manual(values = colours_states) + scale_color_manual(values = c(\"#CDC9C900\", \"#030303\", \"#9370DB\")) + labs(title = \"{Title}\")"
    elif pca_choice == 7:
        # "Gender_Pheno"
        cmd += f"geom_point(aes(color = factor({Gender}), shape = {Phenotype}), size=7) + scale_shape_manual(values = c({shape_number})) + scale_colour_manual(values = colours_genders) + labs(title = \"{Title}\")"
    return cmd



pca_choice = select_pca_plots()
input_dict = pca_plot_inputs(types_of_pca=pca_choice)
BaseOutputDirectory = input_dict["OutputDir"]
DFPath = input_dict["FilePath"]
RScript_Text = f"library(ggplot2)\n\
                # The variables used for colours in the scatter are named as colours_regions & colours_states & colours_genders respectively. Enter these in the R script before execution\n\
                pca = read.csv(\"{DFPath}\", header=TRUE, stringsAsFactors = FALSE)\n"
                
shapes_dict = {
    "Circle-Diamond" : "19,18",
    "Circle_DiamondPlus" : "19,9",
    "Circle_SquarePlus" : "19,12",
    "Circle_Triangle" : "19,17"
}
bord_col_shapes_dict = {
    "Circle_Diamond_BordCols" : "21,23"
}

# Define all principal components to consider - PC1, PC2, PC3....PC10
pcs = [f"PC{i}" for i in range(1, 11)]
# Define all axis reversal types and their suffixes for filenames
reversal_types = {
    "Normal": "",
    "ReverseX": "_ReverseX",
    "ReverseY": "_ReverseY",
    "ReverseBoth": "_ReverseBoth"
}
shapes_to_use = dict.items


# the below algo will be followed to create the R commands that will be added to the RScript text content :


# for each PCA type
    # for each shape present to that PCA type
        # create the appropriate directory
        # for each PNG plot file that is to be generated (combination of pc1 and pc2 etc)
            # for each type of axis reversals that is to be done
            # create the PNG code
            # create the ggplto code
            # acquire the appropriate add on code
            # add the code to the RScript file



# Loop through all selected PCA plot types
for pca_type in pca_choice:                                                                                              # for each PCA type
    # Determine which shape dictionary to use
    if pca_type in [3, 6]:
        shapes_to_use = bord_col_shapes_dict.items()
    else:
        shapes_to_use = shapes_dict.items()
    # Loop through all shape combinations for this PCA type
    for shape_name, shape_number in shapes_to_use:                                               # for each shape available to that PCA type
        # Create output directory for this PCA type and shape
        PlotOutputDir = get_directories(BaseOutputDir=BaseOutputDirectory, pca_choice=pca_type, shapes_combo=shape_name)
        # Loop through all unique pairs of PCs (x != y)
        for xAxis in pcs:                                                                        # for each X & Y combos of PC eigenvectors
            for yAxis in pcs:
                if xAxis == yAxis:
                    continue
                else:
                    # For each axis reversal type
                    for reversal_key, reversal_suffix in reversal_types.items():  # for normal, reverse X, reverse Y, reverse both commands
                        # Construct output PNG filename
                        png_filename = f"{shape_name}_{input_dict['Title']}_{xAxis}_{yAxis}{reversal_suffix}.png"
                        png_path = os.path.join(PlotOutputDir, png_filename)
                        # PNG command
                        png_cmd = f'png("{png_path}", unit="px", width=3000, height=2000, pointsize=1)'
                        # Generate ggplot command
                        ggplot_cmd = command_differentiator(
                            pca_choice=pca_type,
                            x=xAxis,
                            y=yAxis,
                            Phenotype=input_dict["Phenotype"],
                            Title=input_dict["Title"],
                            Gender=input_dict["Gender"],
                            States=input_dict["States"],
                            Regions=input_dict["Regions"],
                            shape_number=shape_number
                        )
                        # Add the common theme and axis reversal code
                        common_theme = pca_plot_standard("Normal")
                        reversal_cmd = ""
                        if reversal_key != "Normal":
                            reversal_cmd = pca_plot_standard(reversal_key)
                            reversal_cmd = f" + {reversal_cmd}"
                        # Compose the full R command
                        full_cmd = (
                            f"{png_cmd}\n\n{ggplot_cmd} + {common_theme}{reversal_cmd}\n\ndev.off()\n\n"
                        )
                        # Append to R script text
                        RScript_Text += full_cmd


with open(f"{input_dict['OutputDir']}/R_ggplots_commands.r", "w") as wrt:
    wrt.write(RScript_Text)

print(f"The R command to plot all these PCA commands is stored at\t:\t{input_dict['OutputDir']}/R_ggplots_commands.r\n\nRun the foll. command to plot it\t:\tRscript {input_dict['OutputDir']}/R_ggplots_commands.r")
