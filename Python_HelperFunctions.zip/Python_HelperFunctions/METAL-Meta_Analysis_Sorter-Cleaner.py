import pandas as pd
import time
import threading


def split_path_name(FullPath : str) -> list:
    """Given a full path to a file, returns the path to the folder, and the file name

    Args:
        FullPath (str): The full path to a file.

    Returns:
        list: A list containing the full path to the folder containing the file as the 0th element, and the file name as the 1st element.
    """
    PathElements = FullPath.split("/")
    FilePath = ""
    # reconstructing path to the folder
    for p in PathElements[1:len(PathElements)-1]:
        FilePath += f"/{p}"
    # getting the filename
    FileName = PathElements[len(PathElements)-1]
    return [FilePath, FileName]


def threads_list_run(ThreadsList : list) -> None:
    """Runs all threads in a given list, waits till completion, then returns

    Args:
        * ThreadsList (list): A list of all the threads that need to be run till completion
    """
    for t in ThreadsList:
        t.start()   
    for t in ThreadsList:
        t.join()
    return


def metal_fuma_dataframe(DfFilePath : str) -> None:
    FilePath, FileName = split_path_name(FullPath=DfFilePath)
    DF = pd.read_csv(DfFilePath, sep="\t")
    print(f"Read the file\t:\t{FileName}\tstored at directory\t:\t{FilePath}")
    # ColsList = list(DF.columns)
    # LowerCaseColumns = list()
    # for c in ColsList:
    #     LowerCaseColumns.append(str(c).lower())
    # DF.columns = LowerCaseColumns
    lock = threading.Lock()
    NewColumns = pd.Series(DF.columns)
    NewColumns = NewColumns.str.replace("MarkerName", "SNP")
    NewColumns = NewColumns.str.replace("P-value", "P")
    DF.columns = NewColumns
    try:
        DF[["CHR", "BP", "A1", "A2"]] = DF["SNP"].str.split(":", expand=True)
    except ValueError as e:
        try:
            DF[["CHR", "BP"]] = DF["SNP"].str.split(":", expand=True)
        except Exception as e:
            print(e)
            raise Exception("Unknown error")
            exit()
    DF["CHR"] = DF["CHR"].astype("str")
    DF["BP"] = DF["BP"].astype("str")
    #checking to see whether there are any X or Y labelled chromosomes & changing them to plink notation
    DF["CHR"] = DF["CHR"].str.replace("X", "23")
    DF["CHR"] = DF["CHR"].str.replace("Y", "24")
    DF["CHR"] = DF["CHR"].str.replace("XY", "25")
    DF["CHR"] = DF["CHR"].str.replace("MT", "26")
    ##########
    DF["MarkerID"] = DF["CHR"] + ":" + DF["BP"]
    DF["CHR"] = DF["CHR"].astype("int")
    DF["BP"] = DF["BP"].astype("int")
    try:
        DF.drop(["A1", "A2"], axis=1,inplace=True)
    except KeyError as e:
        # do nothing and continue on as if nothing has happened
        print("No Cols A1 and A2 to drop. Moving on")
    lock.acquire()
    print(f"\n\nThe meta analysis file that is currently being processed is\t: \n\t\t{FileName}\nwhich is kept at directory\t\t:\n\t\t{FilePath}")
    time.sleep(2)
    NumberOfFiles = int(input("Enter the number of files that were used for meta-analysis\t:\t"))
    Files_ColNames = list()
    for i in range(0,NumberOfFiles):
        TempFileNum = i+1
        DirectionColName = str(input(f"Enter a short name / id for the FILE NUMBER {TempFileNum} used.\tThis will be used to highlight the effect direction for file no. {TempFileNum} column\t:\t"))
        Files_ColNames.append(DirectionColName)
    lock.release()
    DirectionEntries = list()
    for i in range(0,NumberOfFiles):
        DirectionEntries.append(list())
    for direction in DF["Direction"]:
        direction = str(direction)
        Entries = list(direction)
        for count in range(0,NumberOfFiles):
            DirectionEntries[count].append(Entries[count])
    for i in range(0,NumberOfFiles):
        ColName = str(Files_ColNames[i])
        DF[ColName] = DirectionEntries[i]
    NewColumns = pd.Series(DF.columns)
    NewColumns = NewColumns.str.replace("Allele1", "A1_MinorAllele")
    NewColumns = NewColumns.str.replace("Allele2", "A2_MajorAllele")
    NewColumns = NewColumns.str.replace("StdErr", "SE")
    NewColumns = NewColumns.str.replace("Effect", "BETA")
    DF.columns = NewColumns
    DF.sort_values(by="P", inplace=True)
    DF.to_csv(f"{FilePath}/{FileName}_All-SNPs_CleanedColNames.csv", index=False)
    DF.head(100).to_csv(f"{FilePath}/{FileName}_All-SNPs_CleanedColNames_Top100.csv", index=False)
    DF = DF.drop_duplicates(subset=['MarkerID'])
    DF.to_csv(f"{FilePath}/{FileName}_All-SNPs_CleanedColNames_DuplicatesDropped.csv", index=False)
    DF.head(100).to_csv(f"{FilePath}/{FileName}_All-SNPs_CleanedColNames_DuplicatesDropped_Top100.csv", index=False)
    DF = DF[~(DF["Direction"].str.contains("\?"))]
    DF.to_csv(f"{FilePath}/{FileName}_All-SNPs_CleanedColNames_DuplicatesDropped_ONLY-SNPs-COMMON-TO-ALL.csv", index=False)
    DF.head(100).to_csv(f"{FilePath}/{FileName}_All-SNPs_CleanedColNames_DuplicatesDropped_ONLY-SNPs-COMMON-TO-ALL_Top100.csv", index=False)
    

FullMetal_Meta_Analaysis_Paths = list()
EnterPaths = "Y"
while EnterPaths == "Y" or EnterPaths == "y":
    FilePath = str(input("Enter the path of full METAL meta-analysis .TBL result file\t:\t"))
    FullMetal_Meta_Analaysis_Paths.append(FilePath)
    EnterPaths = str(input("Enter\t\"Y\"\t if you want to prepare more Metal Meta-analysis files for FUMA, else enter anything else\t:\t:"))

# for p in FullMetal_Meta_Analaysis_Paths:
#     metal_fuma_dataframe(DfFilePath=p)


for p in FullMetal_Meta_Analaysis_Paths:
    metal_fuma_dataframe(DfFilePath = p)



#ThreadsList = list()
#for p in FullMetal_Meta_Analaysis_Paths:
#    ThreadObject = threading.Thread(target=metal_fuma_dataframe, kwargs={"DfFilePath" : p})
#    ThreadsList.append(ThreadObject)

#threads_list_run(ThreadsList=ThreadsList)

