void setgval (SNP ** xsnps, int nrows, Indiv ** indivmarkers, int numindivs,
	      int *xindex, int *xtypes, int ncols);
void unsetgval ();
int getgval (int row, int col, double *val);
int getggval (int indindx, int col, double *val);
